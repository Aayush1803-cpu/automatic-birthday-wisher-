from flask import Flask, render_template, request
import csv
from datetime import datetime

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    message = ""
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        birthday = request.form['birthday']
        with open('donors.csv', 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([name, email, birthday])
        message = "🎉 Donor added successfully!"
    return render_template('index.html', message=message)

if __name__ == '__main__':
    app.run(debug=True)
