import csv
from datetime import datetime
import smtplib
import random
from email.mime.text import MIMEText

SENDER_EMAIL = 'aayush.mishra.1702@gmail.com'
APP_PASSWORD = 'lgepfeesztnsirog'  # ← no spaces, remove them!

# List of unique birthday messages
MESSAGES = [
    "Wishing you a day filled with sunshine and smiles, laughter and love. Happy Birthday!",
    "May your birthday be the start of a year filled with good luck, good health and much happiness!",
    "You are a gift to this world and we are forever grateful for your support. Have a wonderful birthday!",
    "Your kindness as a donor lights the path for many. May your special day be as generous and joyful as your spirit!",
    "Sending you love and light on your birthday. Thank you for being such an important part of our mission!",
    "Happy Birthday! May your day be full of surprises and your heart full of joy — just like the lives you touch!",
    "You make this world better just by being in it. Today we celebrate you — Happy Birthday from our entire NGO family!",
]

def send_email(name, email):
    personal_message = random.choice(MESSAGES)
    body = f"""Dear {name},

🎉 {personal_message}

With love and gratitude,
— Your NGO Team
"""
    msg = MIMEText(body)
    msg['Subject'] = "🎂 A Special Birthday Wish Just for You"
    msg['From'] = SENDER_EMAIL
    msg['To'] = email

    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            server.login(SENDER_EMAIL, APP_PASSWORD)
            server.send_message(msg)
        print(f"✅ Sent to {name} ({email})")
    except Exception as e:
        print(f"❌ Error sending to {name}: {e}")

def check_and_send():
    today = datetime.now().strftime("%m-%d")
    with open('donors.csv', newline='', encoding='utf-8') as file:
        reader = csv.reader(file)
        next(reader, None)  # Skip header
        for row in reader:
            if len(row) >= 3:
                name, email, birthday = row[0], row[1], row[2]
                if birthday[5:] == today:
                    send_email(name, email)

check_and_send()
